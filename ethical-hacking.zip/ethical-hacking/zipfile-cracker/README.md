# [How to Crack Zip File Passwords in Python](https://www.thepythoncode.com/article/crack-zip-file-password-in-python)
To run this:
- `pip3 install -r requirements.txt`
- Cracking `secret.zip` file with the password list in `wordlist.txt` file, use the following command:
    ```
    python zip_cracker.py secret.zip wordlist.txt
    ```
- For a bigger list, consider downloading [rockyou](https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt) wordlist.