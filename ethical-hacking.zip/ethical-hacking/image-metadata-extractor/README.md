# [How to Extract Image Metadata in Python](https://www.thepythoncode.com/article/extracting-image-metadata-in-python)
To run this:
- `pip3 install -r requirements.txt`
- Extract metadata of the image `image.jpg`:
    ```
    python image_metadata_extractor.py image.jpg
    ```