# [How to Crack PDF Files in Python](https://www.thepythoncode.com/article/crack-pdf-file-password-in-python)
To run this:
- `pip3 install -r requirements.txt`
- Use any `wordlist.txt` you want, and run `pdf_cracker.py`